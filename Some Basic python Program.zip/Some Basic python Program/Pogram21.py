num =  list(range(10))
print(num)
print(num[2])



num =  list(range(5,11)) # starting point, ending point
print(num)

num =  list(range(2,101,2)) # starting point, ending point, difference bettwen number
print(num)