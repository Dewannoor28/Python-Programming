import pyttsx3


engine = pyttsx3.init('sapis')
voices = engine.getProperty('voices')
print(voices[1].id)
engine.setProperty('voices', voices[0].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()
if __name__ == "__main_":
    speak("Noor is a good boy")