Sumaiya = int(input("Enter Sumaiya's value :"))
Dyni = int(input("Enter Dyni's value :"))
Nisthur = int(input("Enter Nisthur's value :"))

# and gate
if Sumaiya > Dyni and Sumaiya > Nisthur :
     print(Sumaiya)
elif Dyni > Sumaiya and Dyni > Nisthur :
     print(Dyni)
else :
     print(Nisthur)

#or gate
'''
if ch == 'a' or ch == 'e' or ch == 'i' or ch = 'o' or ch = 'u' :
    print("Vowel")
else :
    print("Consonant")
'''