i = 1
while i <= 100:

    if i == 20:
        continue
    print(i)
    i = i + 1


print("Dyni")