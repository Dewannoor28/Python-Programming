n  = int(input("Enter the last term of any series :"))
sum = 0
i = 2
while i<=n:
    sum = sum+i
    i = i+2
#print(sum)
print(sum)

