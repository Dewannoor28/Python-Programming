subjects =  ["C","C++","Java","Android ","OS","TOC"]

'''
print(subjects)
print(subjects[0:])
print(subjects[-1])

'''
print("Python" not in subjects)
print("Python" in subjects)
print(subjects + ["Swift",27])