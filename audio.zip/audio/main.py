import pyttsx3
import pyPDF2
