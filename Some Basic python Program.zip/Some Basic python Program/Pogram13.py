dyni = 20
sumu = 10


if dyni > sumu :
    print(dyni)
else :
    print(sumu)
 

#print(num1 if num1>num2 else num2)