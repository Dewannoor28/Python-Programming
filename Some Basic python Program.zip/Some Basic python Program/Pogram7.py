from math import *
a = float(input("Enter any float number"))
b = float(input("Enter any float number"))

print(max(a , b))
print(min(a,b))
print(abs(a))
print(pow(a,b))
print(sqrt(a))
print(round(a))
print(floor(a))
print(ceil(a))


'''
print(max(12,28))
print(min(12,28))
print(abs(-12))
print(pow(28,12))
print(sqrt(12))
print(round(28.6))
print(floor(28.9))
print(ceil(28.5))


'''