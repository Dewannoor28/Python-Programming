
"""
*
**         (2*i-1)
***
****

n = 3
for i in range(n+1):
    #print(i*"*")
    print((5*i-1)*"*")
"""


for i in range(1, 6-i):
    print(" ", end = "*")
