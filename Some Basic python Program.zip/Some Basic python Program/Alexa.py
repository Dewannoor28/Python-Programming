import speech_recognition as sr
import pyttsx3
import pywhatkit
import datetime
import wikipedia
import pyjokes

listener =  sr.Recognizer()
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)
def talk(text):
    engine.say(text)
    engine.runAndWait()

def take_command():
    try:
        with sr.Microphone() as source:
            print('listening...')
            voice = listener.listen(source)
            command = listener.recognize_google(voice)
            command =  command.lower()
            if 'Dyni' in command:
                command = command.replace('Dyni', '')
                print(command)


    except:
        pass
    return command

def run_alexa():
    command =  take_command()
    print(command)
    if 'play' in command:
        song = command.replace('play', '')
        talk('playing' + song)
        pywhatkit.playonyt(song)
    elif 'time' in command:
        time = datetime.datetime.now().strftime('%I:%M %p')
        print(time)
        talk('Current time is ' + time)
    elif 'who is ' in command:
        persion  = command.replace('who is', '')
        info = wikipedia.summary(persion, 1)
        print(info)
        talk(info)
    elif 'date' in command:
        talk('Sorry, I have a headache')
    elif 'are you single?' in command:
         talk("I am a relationship with wifi")
    elif 'joke' in command:
          talk(pyjokes.get_joke())
    elif 'How are you' in command:
          talk('I am fine and you?')
    elif 'What are you doing now?' in command:
        talk('Talking with you')
    elif "Have you any bf" in command:
        talk("Yes, I have many!")
    elif 'Are you nisthur' in command:
        talk('Yes, I very nisthur')
    elif 'say something about you' in command:
        talk('I am DAYNI. I am very nisthur. I have many bf.I have a relationship with many.'
             'I have a skill or you clled that a power.I can hack any kind of heart. If any one looks at my eyes.'
             'he fall in a hallucination. I am vey dangerous')

    else:
          talk('Please say the command again')
          talk('I can not understand')



while True:
    run_alexa()
