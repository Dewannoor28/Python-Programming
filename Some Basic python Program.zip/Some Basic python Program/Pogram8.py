num1 = int(input("Enter any number : "))
num2 = int(input("Enter any number : "))
#num1 = 12
#num2 = 28
print(f"{num1} + {num2} = {num1 + num2}")

print("Sumaiya Tasnim Borno" , end = "") # end using for one line output show
print("Nisthur Dyni")