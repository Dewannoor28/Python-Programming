marks = int(input("Enter your value/marks : "))

if 80 <= marks <= 100:
    print("A+")
elif 70 <= marks <= 79:
    print("A")
elif 60 <= marks <= 69:
    print("A-")
elif 50 <= marks <= 59:
    print("B")
elif 40 <= marks <= 49:
    print("B-")
elif 34 <= marks <= 39:
    print("C")
else:
    print("Sumaiya spoil your life")