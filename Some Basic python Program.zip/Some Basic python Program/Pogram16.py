
#sum=0
i = 2
while i<=100:
    print(i)
    #sum = sum+i
    i = i+2
print("Pogram End") # print(sum)
