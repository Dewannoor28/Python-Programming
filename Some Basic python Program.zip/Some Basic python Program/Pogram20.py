subjects = ["C","C++","Java","Python","BASIC"]
print(len(subjects)) # show lenth or how many list or word in subjects
subjects.append("TOC") #add new list
print(subjects)
subjects.insert(2,"OB") # where you add any list or which position you add this word or list
print(subjects)
subjects.remove("BASIC") #  remove list
print(subjects)
subjects.sort() #arrange word like dictionary
print(subjects)
subjects.reverse() # opposite
print(subjects)
subjects.pop() # remove one word from the last
print(subjects)
subjects2 = subjects.copy()
pos = subjects.index("Java") # position any word which is included in the list
print(pos)
pos = subjects.count("Java")
print(pos)