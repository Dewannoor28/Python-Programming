base = float(input("Enter Base :"))
height = float(input("Enter height :"))

area = 0.5*base*height
print(area)