# Sumaiya's Biodata
'''
Name : Sumaiya
Skill   : hack heart, dyni giri, innocent clever,
Humanity : Nisthur
Access code : 12

'''



print("\"Sumaiya is the super dynii\"")








print("12")

