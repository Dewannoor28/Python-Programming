
#even/odd

num =  4

if  num % 2 == 0:
    print("Even")

else :
    print("Odd")


#large
'''
 num1 = 20
 num2 = 10

 if num1>num2;
     print(num1)
else ;
     print(num2)
'''