
Sumaiya = int(input("Enter Sumaiya's value :"))
Dyni = int(input("Enter Dyni's value :"))
Nisthur = int(input("Enter Nisthur's value :"))


if Sumaiya > Dyni :
  if Sumaiya > Nisthur :
     print(Sumaiya)
  else :
     print(Nisthur)
     print("Sumaiya is Nisthur")

if Dyni > Sumaiya :
  if Dyni > Nisthur :
     print(Dyni)
     print("Sumaiya is Dyni")
  else :
     print(Nisthur)
     print("Sumaiya is Nisthur")