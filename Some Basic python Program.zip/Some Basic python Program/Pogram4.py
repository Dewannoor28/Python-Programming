name = input("Enter Your name :")
age = input("Enter your age :")
skil = input("Enter your skill :")

print(" Someone's Anoynomous Details ")
print("-------------------------------")
print("Name : " +name)
print("Age : " +age)
print("Skill :" +skil)