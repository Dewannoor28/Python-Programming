

n  =  int(input("Enter the last number :"))
result =  1

for x in range(n,0,-1):
      result =  result * x
print(result)