import pyttsx3

book = open('')
speaker = pyttsx3.init()
speaker.say('Look Mama I can talk')
speaker.runAndWait()