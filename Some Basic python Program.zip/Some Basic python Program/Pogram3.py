a = 12
b = 28

print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a%b)
print(a//b)
print(b//a)
print(a**b)

