n = int(input("Enter the last number :"))
fact = 1

for x in range(n,0,-1):
    fact = fact * x

print("factorial of" , n , "is", fact)

