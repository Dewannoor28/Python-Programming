name = " Sumaiya  "
age = 20
print(name + " full name is Sumaiya Tasnim Borno " )
print(" She is currntly ", age , " years old ")
print(" she is pure Single but sometimes you think that she has many bf ")
print( name + " is a innocent girl but clever ")
print(name + " has some skill which are hack herat, Dynii, Nisthur, innocent, decent, Selfish ")
print(name + " has a beautiful heart but full of satanic intellect ")
print( name +"looks like innocent but dangerous ")
print(" So it's better to try to stay away from her ")
print(name +" has some favourite passion . some of them are photography, travelling, tipping phone, seelping ")
print(name +"has some weakness . If you try to impress her, you take her for travelling or buy a choklet.\n I guess she definately obey you for a few times.This time you can do anything with her(don't take it negatively) " )
print(name + "is very talkative and sociable girl. So if you try understand her, you can also sociable with her ")